Hi to all Bacially it took  a long time but at last ive done it
I created files in git and commited and pushed to github later buils images from Docker
Those imges are pushed to Dockerhub
For Deployment i used Render 
And thats it the application is Deployed 
I mentioned the URL for the application in the files i hope you can go through it
